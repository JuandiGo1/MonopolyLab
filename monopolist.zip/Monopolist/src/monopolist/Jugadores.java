/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolist;

import java.awt.Color;
import java.io.File;
import javafx.embed.swing.JFXPanel;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS TUF GAMING F15
 */
public class Jugadores {

    String nick;
    double dinero = 1500;
    int turno;
    Casillas Propiedades[]=new Casillas[28];
    int CantPropiedades;
    JLabel Ficha, VerDinero;
    int casillaUbicado = 0;
    int NroJugador;
    boolean preso;

    Jugadores(String name, int turn, JLabel p, int Nro, JLabel p2) {
        this.nick = name;
        this.turno = turn;
        this.Ficha = p;
        this.VerDinero = p2;
        this.NroJugador = Nro;
        //this.Propiedades = new Casillas[28];
        this.CantPropiedades = 0;
        this.preso = false;
    }

    public void Encarcelar() {
        Icon poli = new javax.swing.ImageIcon(getClass().getResource("/imagenes/police.png"));
        new JFXPanel();
        String dd = new File("policia.mp3").toURI().toString();
        new MediaPlayer(new Media(dd)).play();
        JOptionPane.showMessageDialog(null, "<html><p style=\" color:blue; font:20px ;font face='Eras Bold'; \"> ¡A LA CARCEL!<p><html>",
                "VE A LA CARCEL", JOptionPane.PLAIN_MESSAGE, poli);
        this.preso = true;
        this.casillaUbicado = 10;
        switch (this.NroJugador) {
            case 1:

                this.Ficha.setBounds(50, 647, 25, 25);
                break;
            case 2:

                this.Ficha.setBounds(90, 647, 25, 25);
                break;
            case 3:

                this.Ficha.setBounds(50, 687, 25, 25);
                break;
            case 4:

                this.Ficha.setBounds(90, 687, 25, 25);
                break;
        }
        Tablero.Historial.setText(Tablero.Historial.getText() + "\n" + this.nick + " fue privado de su libertad :(");
    }
    
    public int propiedadesConjunto(Color colo){
        int cant=0;
        System.out.println("entró");
        String com = colo+"";
        System.out.println(com);
        for (int i = 0; i < this.CantPropiedades; i++) {
            System.out.println(Propiedades[i].color+"");
            String act= Propiedades[i].color+"";
            if(act.equals(com)){
                cant++;
            }
        }
        return cant;
    }
}

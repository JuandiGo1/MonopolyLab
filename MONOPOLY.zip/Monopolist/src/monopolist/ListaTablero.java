/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolist;

import javax.swing.JLabel;

/**
 *
 * @author ASUS TUF GAMING F15
 */
public class ListaTablero {

    class Celda {

        Casillas Casilla;
        Celda next;
        Celda prev;

        public Celda(Casillas d) {
            this.Casilla = d;
            this.next = null;
            this.prev = null;

        }
    }
    //Represent the head and tail of the singly linked list
    Celda head = null;
    Celda tail = null;

    public void addNode(Casillas Casilla) {
        Celda P = new Celda(Casilla);
        if (head == null) {
            head = P;
            tail = P;
        } else {
            tail.next = P;
            P.prev = tail;
            tail = P;
        }

        head.prev = tail;
        tail.next = head;
    }

    public Celda Buscar(Jugadores J, boolean mostrar) {
        Celda P = head;
        Celda Q=null;
        boolean encontro = false;
        while (P.next != head & encontro == false) {
            if (P.Casilla.num == J.casillaUbicado) {
                if (mostrar == true) {
                    Tablero.ProName.setBackground(P.Casilla.color);
                    Tablero.ProName.setText(P.Casilla.name);
                    Tablero.precio.setText(P.Casilla.ValVenta + "");
                    Tablero.alquiler.setText(P.Casilla.ValRenta + "");
                }
                encontro = true;
                Q = P;
                
            }else{
                P = P.next;
            }
            
        }
        return Q;
    }

    public void MoverFicha(Jugadores J, int rdados, int player) {

        if (J.casillaUbicado < 42) {
            switch (player) {
                case 1:
                    J.casillaUbicado += rdados;
                    Celda P= Buscar(J, true);
                    int newx= P.Casilla.posx-20;
                    int newy= P.Casilla.posy-20;
                    J.Ficha.setBounds(newx, newy, 25, 25);

            }

        }
    }

}

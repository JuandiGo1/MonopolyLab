/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolist;

import javax.swing.JLabel;

/**
 *
 * @author ASUS TUF GAMING F15
 */
public class Jugadores {
    String nick;
    double dinero = 1500;
    int turno;
    //Propiedades: ?
    JLabel Ficha;
    int casillaUbicado=0;
    
    Jugadores(String name, int turn, JLabel p){
        this.nick = name;
        this.turno = turn;
        this.Ficha = p;
    }
    
}


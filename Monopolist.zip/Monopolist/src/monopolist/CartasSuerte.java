/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monopolist;

/**
 *
 * @author ASUS TUF GAMING F15
 */
public class CartasSuerte {
    String descrip;
    String accion;
    int valor;
    int NroCarta;

    public CartasSuerte(String descrip, String accion, int valor, int NroCarta) {
        this.descrip = descrip;
        this.accion = accion;
        this.valor = valor;
        this.NroCarta = NroCarta;
    }
    
    
}
